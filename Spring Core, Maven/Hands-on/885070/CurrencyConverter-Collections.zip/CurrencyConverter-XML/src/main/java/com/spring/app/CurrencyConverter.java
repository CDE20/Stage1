package com.spring.app;
import java.util.*;

public class CurrencyConverter {
    
        private Map<String, String> mObj;

	    public void setmObj(Map<String, String> mObj) {
		    this.mObj = mObj;
	    }
	    public int getTotalCurrencyValue(String value)
    	{
    	    String temp = value;
    	    int num= Integer.parseInt(temp.replaceAll("[^0-9]", ""));
		    String currencyType = temp.replaceAll("[^A-Za-z]", "");
		    
		    int result = 0;
		    Set<String> keys = mObj.keySet();
		    for(String str: keys){
		        if(str.equalsIgnoreCase(currencyType)){
		            result = (num * (Integer.parseInt(mObj.get(str))));
		            break;
		        }
		    }
	        return result;
	 
	    }	
}
