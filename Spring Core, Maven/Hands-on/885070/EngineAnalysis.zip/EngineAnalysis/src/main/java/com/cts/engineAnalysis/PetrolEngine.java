package com.cts.engineAnalysis;

public class PetrolEngine  extends Engine{

	@Override
	public int getPerformance() {
		int horsepower = (this.getTorque()*this.getRpm())/5252;
		return horsepower;
	}

// Type your code here
	
	

}
