package com.app.driver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

 
public class Main {
 
	@SuppressWarnings("resource")
	public static void main(String[] args) {
    ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
     System.out.println("oracle.jdbc.driver.OracleDriver");
     System.out.println("jdbc:oracle:thin:@localhost:1521:oracle");
     System.out.println("john");
     System.out.println("john@123");
		
	}
}