package com.spring.ui;
import com.spring.app.AddressBook;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;
public class Driver {
	
	
	public static AddressBook loadAddressBook()
	{
	    
		ClassPathXmlApplicationContext c = new ClassPathXmlApplicationContext("applicationContext.xml");
		AddressBook ab = (AddressBook) c.getBean("addressbook");
		return ab;
		//return null;
	}
	
	public static void main(String[] args)
	{
		//invoke the loadAddressBook() method from main retrieve the AddressBook object, get the details from the user set the values and display the values
        Scanner k = new Scanner(System.in);

		AddressBook addr = loadAddressBook();

		System.out.println("Enter the temporary address");

		System.out.println("Enter the house name");

		addr.setHouseName(k.nextLine());

		System.out.println("Enter the street");

		addr.setStreet(k.nextLine());

		System.out.println("Enter the city");

		addr.setCity(k.nextLine());

		System.out.println("Enter the state");

		addr.setState(k.nextLine());

		System.out.println("Enter the phone number");

		addr.setPhoneNumber(k.next());

		System.out.println("Temporary address");

		System.out.println("House name:" + addr.getHouseName());

		System.out.println("Street:" + addr.getStreet());

		System.out.println("City:" + addr.getCity());

		System.out.println("State:" + addr.getState());

		System.out.println("Phone number:" + addr.getPhoneNumber());

	}

}
