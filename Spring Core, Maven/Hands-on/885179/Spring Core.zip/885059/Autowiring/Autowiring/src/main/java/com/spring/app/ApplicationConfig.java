package com.spring.app;
import org.springframework.context.annotation.*;
@Configuration
@ComponentScan(basePackages = "com.spring.app")
public class ApplicationConfig {

}
