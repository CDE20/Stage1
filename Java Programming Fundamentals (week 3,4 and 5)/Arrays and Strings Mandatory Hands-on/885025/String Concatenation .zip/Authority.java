import java.util.*;
import java.util.regex.*;
public class Authority{
    public static void main (String[] args) {
         Scanner sc=new Scanner(System.in);
         System.out.print("Inmate's name:");
         String s1=sc.nextLine();
         System.out.println();
         boolean b=Pattern.matches("[a-zA-Z\\s]+",s1);
         System.out.print("Inmate's father's name:");
         String s2=sc.nextLine();
         System.out.println();
         boolean b1=Pattern.matches("[a-zA-Z\\s]+",s2);
         if(!b)
         {
             System.out.println("Invalid name");
         }
         else if(!b1)
         {
             System.out.println("Invalid name");
    
         }
         else
         System.out.println(s1.toUpperCase()+" "+s2.toUpperCase());
         
         
    }
}