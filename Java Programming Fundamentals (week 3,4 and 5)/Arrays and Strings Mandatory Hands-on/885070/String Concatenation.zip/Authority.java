import java.util.*;
public class Authority{
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Inmate's name:");
        String name = s.nextLine();
        System.out.print("\nInmate's father's name:");
        String fatherName = s.nextLine();
        if(!(name.matches("[a-zA-Z ]+"))){
            System.out.println("Invalid name");
            return;
        }
        if(!(fatherName.matches("[a-zA-Z ]+"))){
            System.out.println("Invalid name");
            return;
        }
        String upperName = name.toUpperCase()+ " ";
        String upperFatherName = fatherName.toUpperCase();
        System.out.println(upperName.concat(upperFatherName));
    }
}