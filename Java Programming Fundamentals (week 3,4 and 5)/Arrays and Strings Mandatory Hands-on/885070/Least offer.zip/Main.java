import java.util.*;
public class Main{
    String name;
    int price;
    int discount;
    public static void main (String[] args) {
     Scanner sc=new Scanner(System.in);
     int items = sc.nextInt();
     sc.nextLine();
     Main[] arr = new Main[items];
     for(int i =0;i<arr.length;i++){
         arr[i]= new Main();
         String input = sc.nextLine();
         String[] value = input.split(",");
         arr[i].name = value[0];
         arr[i].price = Integer.parseInt(value[1]);
         arr[i].discount = Integer.parseInt(value[2]);
     }
     int min = Integer.MAX_VALUE;
     double disPrice = 0.0;
     for(int i=0;i<arr.length;i++){
         disPrice = arr[i].price *((double)arr[i].discount/100);
         if(min > (int)disPrice){
             min = (int)disPrice;
         }
     }
     for(int i = 0;i<arr.length;i++){
         double disPriceNew = arr[i].price * ((double)arr[i].discount/100);
         if(min==(int)disPriceNew){
             System.out.println(arr[i].name);
         }
     }
        
    }
}