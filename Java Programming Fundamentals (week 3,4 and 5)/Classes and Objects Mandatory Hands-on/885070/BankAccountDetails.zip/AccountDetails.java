import java.util.*;
public class AccountDetails {
	public static Account getAccountDetails(){
        Scanner s = new Scanner(System.in);
        System.out.println("Enter account id:");
        int id = s.nextInt();
        System.out.println("Enter account type:");
        String accountType = s.next();
        int balance = 0;
        while(true){
            System.out.println("Enter balance:");
            balance = s.nextInt();
            if(balance>0){
                break;
            }
        }
        Account ac = new Account();
        ac.setAccountId(id);
        ac.setAccountType(accountType);
        ac.setBalance(balance);
        return ac;
    }
    
    public static int getWithdrawAmount(){
        Scanner sc = new Scanner(System.in);
        int amount;
        while(true){
            System.out.println("Enter amount to be withdrawn:");
            amount = sc.nextInt();
            if(amount>0){
                break;
            }
            System.out.println("Amount should be positive");
        }
        return amount;
        
    }
    public static void main (String[] args) {
        Account account = getAccountDetails();
        int withdrawAmount = getWithdrawAmount();
        account.withdraw(withdrawAmount);
    }
}
