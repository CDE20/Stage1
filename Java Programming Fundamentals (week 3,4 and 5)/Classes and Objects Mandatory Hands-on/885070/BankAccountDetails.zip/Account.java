public class Account{
    private int accountId;
    private String accountType;
    private int balance;
    
    public void setAccountId(int accountId){
        this.accountId = accountId;
    }
    
    public void setAccountType(String accountType){
        this.accountType = accountType;
    }
    
    public void setBalance(int balance){
        this.balance = balance;
    }
    
    public int getAccountId(){
        return this.accountId;
    }
    
    public String getAccountType(){
        return this.accountType;
    }
    
    public int getBalance(){
        return this.balance;
    }
    
   public boolean withdraw(int amount){
	        int withdrawAmount = amount;
        if(withdrawAmount<=this.balance){
            int remainingBalance = this.balance - withdrawAmount;
            System.out.println("Balance amount after withdraw: "+remainingBalance);
            return true;
        }else{
            System.out.println("Sorry!!! No enough balance");
            return false;
        }
    }
    
}