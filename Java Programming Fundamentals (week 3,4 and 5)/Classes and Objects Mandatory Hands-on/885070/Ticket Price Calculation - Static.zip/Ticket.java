public class Ticket{
    private int ticketid;
    private int price;
    private static int availableTickets;
    
    public void setTicketid(int ticketid){
        this.ticketid = ticketid;
    }
    public int getTicketid(){
        return this.ticketid;
    }
    public void setPrice(int price){
        this.price = price;
    }
    public int getPrice(){
        return this.price;
    }
    
    public static void setAvailableTickets(int availableTickets){
        if(availableTickets<=0){
            return;
        }
        Ticket.availableTickets = availableTickets;
    }
     public static int getAvailableTickets(){
         return Ticket.availableTickets;
     }
    public int calculateTicketCost(int nooftickets){
        if(nooftickets<=availableTickets){
            availableTickets -= nooftickets;
            int totalamount = nooftickets*this.price;
            return totalamount;
        }else{
            return -1;
        }
    }
}