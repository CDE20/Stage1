import java.util.Scanner;
public class Main{
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter no of bookings:");
        int numBooking = s.nextInt();
        System.out.println("Enter the available tickets:");
        int availableTickets = s.nextInt();
        Ticket t = new Ticket();
        Ticket.setAvailableTickets(availableTickets);
        for(int i =1; i<=numBooking; i++){
            System.out.println("Enter the ticketid:");
            int ticketid = s.nextInt();
            t.setTicketid(ticketid);
            System.out.println("Enter the price:");
            int price = s.nextInt();
            t.setPrice(price);
            System.out.println("Enter the no of tickets:");
            int nooftickets = s.nextInt();
            System.out.println("Available tickets: "+Ticket.getAvailableTickets());
            int totalAmount = t.calculateTicketCost(nooftickets);
            System.out.println("Total amount:"+totalAmount);
            System.out.println("Available ticket after booking:"+Ticket.getAvailableTickets());
        }
    }
}