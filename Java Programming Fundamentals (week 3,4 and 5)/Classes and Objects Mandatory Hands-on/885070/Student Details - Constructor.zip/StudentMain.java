import java.util.*;
public class StudentMain{
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter Student's Id:");
        int id = s.nextInt();
        System.out.println("Enter Student's Name:");
        String name = s.next();
        System.out.println("Enter Student's address:");
        String address = s.next();
        while(true){
            System.out.println("Whether the student is from NIT(Yes/No):");
            String ans = s.next();
            if(ans == "YES" || ans == "yes"){
                Student student = new Student(id,name,address);
                student.print();
                break;
            }else if(ans == "NO" || ans == "no") {
                System.out.println("Enter the college name:");
                String collegeName = s.next();
                Student student = new Student(id, name, address, collegeName);
                student.print();
                break;
            }

            
        }
        return; 
        
    }
}