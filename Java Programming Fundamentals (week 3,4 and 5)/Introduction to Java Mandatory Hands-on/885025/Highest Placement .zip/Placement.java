import java.util.*;
public class Placement{
    public static void main (String[] args) {
           Scanner sc=new Scanner(System.in);
           System.out.print("Enter the no of students placed in CSE:");
           int cse=sc.nextInt();
           System.out.println();
           System.out.print("Enter the no of students placed in ECE:");
           int ece=sc.nextInt();
           System.out.println();
           System.out.print("Enter the no of students placed in MECH:");
           int mech=sc.nextInt();
           System.out.println();
           if(cse<0 || ece<0 || mech<0)
           {
              System.out.println("Input is Invalid"); 
              System.exit(0);
           }
           if(cse==ece && ece==mech)
           {
             System.out.println("None of the department has got the highest placement"); 
              System.exit(0);  
           }
           System.out.println("Highest placement");
           if(cse>=ece && cse>=mech){
               System.out.println("CSE");
               if(cse==ece)
                  System.out.println("ECE");
               else
                  if(cse==mech)
                     System.out.println("MECH");
           }
           else{
               if(ece>=cse && ece>=mech){
                  System.out.println("ECE");
                  if(ece==mech)
                     System.out.println("MECH");
               }
               else
                   System.out.println("MECH");
           }
           
    }
}