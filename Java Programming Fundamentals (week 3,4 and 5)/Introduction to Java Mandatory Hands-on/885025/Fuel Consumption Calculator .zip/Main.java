import java.util.*;
public class Main{
    public static void main (String[] args) {
         Scanner sc=new Scanner(System.in);
         System.out.println("Enter the no of liters to fill the tank");
         float lit=sc.nextFloat();
         if(lit<=0)
            {System.out.println((int)lit+" is an Invalid Input");
                System.exit(0);
            }
         System.out.println("Enter the distance covered");
         float dis=sc.nextFloat();
         if(dis<=0)
            {System.out.println((int)dis+" is an Invalid Input");
                System.exit(0);
            }
        float o1=(float)((lit/dis)*100);
        float o2=(float)((dis*0.6214)/(lit*0.2642));
        System.out.println("Liters/100KM");
        System.out.printf("%.2f",o1);
        System.out.println();
        System.out.println("Miles/gallons");
        System.out.printf("%.2f",o2);
        
          
    }
}