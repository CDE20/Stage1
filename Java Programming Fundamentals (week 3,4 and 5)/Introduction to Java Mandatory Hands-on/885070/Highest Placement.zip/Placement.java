import java.util.Scanner;
public class Placement{
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the no of students placed in CSE:");
        int cseMarks = s.nextInt();
        System.out.println("Enter the no of students placed in ECE:");
        int eceMarks = s.nextInt();
        System.out.println("Enter the no of students placed in MECH:");
        int mechMarks = s.nextInt();
        if(cseMarks<0 || eceMarks<0 || mechMarks<0){
            System.out.println("Input is Invalid");
            return;
        }
        if((cseMarks == eceMarks) && (eceMarks == mechMarks)){
            System.out.println("None of the department has got the highest placement");
            return;
        }
        System.out.println("Highest Placement");
        if ((cseMarks>eceMarks)&&(cseMarks>mechMarks))
            System.out.println("CSE");
        else if ((eceMarks>cseMarks)&&(eceMarks>mechMarks))
            System.out.println("ECE");
        else if ((mechMarks>cseMarks)&&(mechMarks>eceMarks))
            System.out.println("MECH");
        else if ((mechMarks==cseMarks)&&(cseMarks>eceMarks))
            System.out.println("CSE\nMECH");
        else if ((mechMarks==eceMarks)&&(mechMarks>cseMarks))
            System.out.println("ECE\nMECH");
        else if ((eceMarks==cseMarks)&&(eceMarks>mechMarks))
            System.out.println("CSE\nECE");
    }
}