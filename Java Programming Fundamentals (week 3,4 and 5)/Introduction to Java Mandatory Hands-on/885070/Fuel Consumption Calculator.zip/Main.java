import java.util.Scanner;
public class Main{
    public static void main (String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the no of liters to fill the tank");
        int liters = s.nextInt();
        if(liters<=0){
            System.out.println(liters+" is an Invalid Input");
            return;
        }
        System.out.println("Enter the distance covered");
        int distance = s.nextInt();
        if(distance<=0){
            System.out.println(distance+" is an Invalid Input");
            return;
        }
        double fuelConsumption = ((double)liters/distance) * 100;
        double miles = distance * 0.6214;
        double galllons = liters*0.2642;
        double milesPerGallons = (miles/galllons);
        System.out.printf("Liters/100KM\n%.2f",fuelConsumption);
        System.out.printf("\nMiles/gallons\n%.2f",milesPerGallons);
    }
}