public interface Loan{
    public double issueLoan();
}