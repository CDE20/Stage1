package com.ui;
import com.utility.*;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) {
		Bazaar b = new Bazaar();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the no of Policy names you want to store");
		int num = sc.nextInt();
		for(int i = 0; i<num; i++){
		    System.out.println("Enter the policy ID");
		    int key = sc.nextInt();
		    sc.nextLine();
		    System.out.println("Enter the Policy Name");
		    String value = sc.nextLine();
		    b.addPolicyDetails(key,value);
		}
		
		for(int i : b.getPolicyMap().keySet()){
		    System.out.println(i+" "+b.getPolicyMap().get(i));
		}
		
		System.out.println("Enter the policy type to be searched");
		String policyType = sc.nextLine();
		List<Integer> list = b.searchBasedOnPolicyType(policyType);
		for(int i = 0; i<list.size(); i++){
		    System.out.println(list.get(i));
		}

	}

}
