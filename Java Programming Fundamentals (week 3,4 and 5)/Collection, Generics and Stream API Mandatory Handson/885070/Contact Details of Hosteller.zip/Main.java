import java.util.Scanner;

public class Main {

	public static Hosteller getHostellerDetails() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the Details:");
		System.out.println("Student Id");
		int studentId = s.nextInt();
		s.nextLine();
		System.out.println("Student Name");
		String name = s.nextLine();
		System.out.println("Department Id");
		int departmentId = s.nextInt();
		s.nextLine();
		System.out.println("Gender");
		String gender = s.next();
		System.out.println("Phone Number");
		String phone = s.next();
		System.out.println("Hostel Name");
		String hostelName = s.next();
		System.out.println("Room Number");
		int roomNumber = s.nextInt();
		System.out.println("Modify Room Number(Y/N)");
		char ans = s.next().charAt(0);
		if(ans == 'Y') {
			System.out.println("New Room Number");
			roomNumber = s.nextInt();
		}
		System.out.println("Modify Phone Number(Y/N)");
		char ans2 = s.next().charAt(0);
		if(ans2 == 'Y') {
			System.out.println("New Phone Number");
			phone = s.next();
		}
		Hosteller host = new Hosteller();
		host.studentId = studentId;
		host.name = name;
		host.departmentId = departmentId;
		host.gender = gender;
		host.phone = phone;
		host.setHostelName(hostelName);
		host.setRoomNumber(roomNumber);
		return host;

	}

	public static void main(String[] args) {
		Hosteller host = getHostellerDetails();
		System.out.print(host.studentId+" "+host.name+" "+host.departmentId+" "+host.gender+" "+host.phone+" "+host.getHostelName()+" "+host.getRoomNumber());
	}

}