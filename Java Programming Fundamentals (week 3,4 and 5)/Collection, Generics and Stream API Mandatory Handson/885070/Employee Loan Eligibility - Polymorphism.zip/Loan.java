
public class Loan {
	
	public double loanAmount;
	
	//Implement the below method 
	
	public double calculateLoanAmount(Employee employeeObj) {
		
		if(employeeObj instanceof PermanentEmployee){
		    this.loanAmount = 0.15 * employeeObj.salary;
		}
		if(employeeObj instanceof TemporaryEmployee){
		    this.loanAmount = 0.10 * employeeObj.salary;
		}
	return this.loanAmount;
	}

}
