//import the necessary packages if needed
import java.util.*;
     
@SuppressWarnings("unchecked")//Do not delete this line
public class UniqueWords
{
      public static void main (String[] args) {
          Scanner s = new Scanner(System.in);
          System.out.println("Enter Student's Article");
          String article = s.nextLine();
          article = article.replaceAll("[^a-zA-Z'\\s]", "").toLowerCase();
          String articleArray[] = article.split(" ");
          System.out.println("Number of words "+articleArray.length);
          Set<String> articleSet = new TreeSet<String>(Arrays.asList(articleArray));
          System.out.println("Number of unique words "+articleSet.size());
          int count = 1;
          System.out.println("The words are");
          for(String str:articleSet){
              System.out.println(count+"."+" "+str);
              count++;
          }
      }   
}