//import the necessary packages if needed
import java.util.*;
     
@SuppressWarnings("unchecked")//Do not delete this line
public class UniqueWords
{
    public static void main (String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter Student's Article");
        String input = sc.nextLine();
              input=input.toLowerCase();
              input=input.replaceAll("[^a-zA-Z'\\s_-]", "");
              String[] arr = input.split(" ");
        
        List<String> l = Arrays.asList(arr);
        TreeSet<String> h = new TreeSet<>(l);
        System.out.println("Number of words "+l.size());
        System.out.println("Number of unique words "+h.size());
        System.out.println("The words are");
        int i=1;
        Iterator it=h.iterator();
        while(it.hasNext()){
            System.out.println((i++) +". "+it.next());
        }
        
    }
         
}