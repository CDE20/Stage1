import java.util.*;
public class ArrayException extends Exception{
    
    public String getPriceDetails(){
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the number of elements int the array");
        int size = s.nextInt();
        int arr[] = new int[size];
        String str = "";
        System.out.println("Enter the price details");
        for(int i = 0; i<size; i++){
            try{
                arr[i] = s.nextInt();
            }catch(InputMismatchException e){
                return str = "Input was not in the correct format";
            }
        }
        System.out.println("Enter the index of the array element you want to access");
        try {
            int index = s.nextInt();
            str = "The array element is " + arr[index];
        } catch(ArrayIndexOutOfBoundsException e) {
            str = "Array index is out of range";
        }
        return str;
    }
    
    public static void main (String[] args) {
        ArrayException ae = new ArrayException();
        System.out.println(ae.getPriceDetails());
    }
}