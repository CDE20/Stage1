import java.util.*;
public class Main{
    
        public static Candidate getCandidateDetails() throws InvalidSalaryException{
    	Candidate candidate = null;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the candidate Details");
        System.out.println("Name");
        String name = s.next();
        System.out.println("Gender");
        String gender = s.next();
        System.out.println("Expected Salary");
        double salary = s.nextDouble();
        try {
        	if(salary<10000) {
        		throw new InvalidSalaryException("Registration Failed. Salary cannot be less than 10000");
        	}
        }finally {
        	candidate = new Candidate();
        }
        candidate.setName(name);
        candidate.setGender(gender);
        candidate.setExpectedSalary(salary);
        
        return candidate;
    }
    public static void main (String[] args) {
        try {
			Candidate c = getCandidateDetails();
			System.out.println("Registration Successful");
		} catch (InvalidSalaryException e) {
			e.getMessage();
		}
        
    }
}