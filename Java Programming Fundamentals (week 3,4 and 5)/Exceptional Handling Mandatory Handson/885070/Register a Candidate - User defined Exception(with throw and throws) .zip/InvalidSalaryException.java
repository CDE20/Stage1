public class InvalidSalaryException extends Exception{
	public String message;
	public InvalidSalaryException(String s) {
    	this.message = s;
	}
	public String getMessage() {
		return message;
	}
}