import java.util.*;
import java.util.regex.Pattern;

public class ValidateUtility
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        String product = sc.nextLine();
        Validate a = ValidateUtility.validateEmployeeName();
        if(a.validateName(name)==true){
            System.out.println("Employee name is valid");
        }else{
            System.out.println("Employee name is invalid");
        }
        Validate b = ValidateUtility.validateProductName();
        if(b.validateName(product)==true){
            System.out.println("Product name is valid");
        }else{
            System.out.println("Product name is invalid");
        }
    }
    
    public static Validate validateEmployeeName() 
    {
        Validate validname = (String Name)->{
            String regex = "^[A-Za-z ]{5,20}$";
            boolean match = Pattern.matches(regex,Name);
            return match;
        };
        return validname;
    }
    
    public static Validate validateProductName() 
    {
        Validate validproduct = (String Product) ->{
            Pattern pattern;
            String regex = "[a-zA-Z][0-9]{5}$";
            boolean match = Pattern.matches(regex,Product);
            return match;
        };
        return validproduct;
    }
}