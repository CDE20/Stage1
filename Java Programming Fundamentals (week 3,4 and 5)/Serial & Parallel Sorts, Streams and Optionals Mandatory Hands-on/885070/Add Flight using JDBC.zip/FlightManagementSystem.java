import java.sql.*;
public class FlightManagementSystem{
    public boolean addFlight(Flight flightObj){
        int a = flightObj.getFlightId();
        String b = flightObj.getSource();
        String c = flightObj.getDestination();
        int d = flightObj.getNoOfSeats();
        double e = flightObj.getFlightFare();
        try{
            String url = "jdbc:mysql://localhost:3306/flight";
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DB.getConnection();
            PreparedStatement st = con.prepareStatement("insert into flight values(?,?,?,?,?)");
            st.setInt(1,a);
            st.setString(2,b);
            st.setString(3,c);
            st.setInt(4,d);
            st.setDouble(5,e);
            int count = st.executeUpdate();
            st.close();
            con.close();
            if(count>0){
                return true;
            }else{
                return false;
            }
        }catch(Exception ex){
                return false;
            }
    }
}