import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        FlightManagementSystem fd = new FlightManagementSystem();
        int flightId = sc.nextInt();
        sc.nextLine();
        String source = sc.nextLine();
        String destination = sc.nextLine();
        int noOfSeats = sc.nextInt();
        double flightFare = sc.nextDouble();
        Flight f = new Flight(flightId,source,destination,noOfSeats,flightFare);
        boolean result = fd.addFlight(f);
        if(result){
            System.out.println("Flight Details added successfully");
        }else{
            System.out.println("Addition not done");
        }
    }
}