import java.util.*;

public class UserInterface {

	public static CommissionInfo generateCommissionObtained() {
		CommissionInfo comInfoObj = (ticketObj) -> {
			double com = 0.0;
			String classType = ticketObj.getClassType();
			System.out.println(classType);
			if (classType.equalsIgnoreCase("SL") || classType.equalsIgnoreCase("2S")) {
				com = 60;
			} else {
				com = 100.0;
			}
			return com;
		};
		return comInfoObj;
	}

	public static void main(String args[]) {

		Scanner s = new Scanner(System.in);
		System.out.println("Enter the no of passengers");
		int count = s.nextInt();
		Ticket[] arr = new Ticket[count];
		for (int i = 1; i <= count; i++) {
			System.out.println("Details of Passenger " + i + ":");
			System.out.println("Enter the pnr no:");
			long pnr = s.nextLong();
			System.out.println("Enter passenger name:");
			String name = s.next();
			System.out.println("Enter seat no:");
			int seat = s.nextInt();
			System.out.println("Enter class type:");
			String classType = s.next();
			System.out.println("Enter ticket fare:");
			double fare = s.nextDouble();
			arr[i - 1] = new Ticket(pnr, name, seat, classType, fare);
		}
		CommissionInfo obj = generateCommissionObtained();
		double sum = 0.0;
		for (int i = 0; i < arr.length; i++) {
			double temp = obj.calculateCommissionAmount(arr[i]);
			System.out.println(temp);
			sum = sum + temp;
		}
		System.out.printf("Commission Obtained\nCommission obtained per each person: Rs.%.2f", sum);
		

	}

}
