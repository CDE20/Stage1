import java.util.ArrayList;

public interface EmployeeAudit {

	public ArrayList<String> fetchEmployeeDetails(double salary);
}
