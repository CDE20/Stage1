import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.*;

public class Main {

	private static Map<String, Double> employeeMap = new HashMap<>();

// 	public Main() {
// 		employeeMap = new HashMap<>();
// 	}

	public Map<String, Double> getEmployeeMap() {
		return employeeMap;
	}

	public void setEmployeeMap(Map<String, Double> employeeMap) {
		this.employeeMap = employeeMap;
	}

	public void addEmployeeDetails(String employeeName, double salary) {
		employeeMap.put(employeeName, salary);
	}

	public static EmployeeAudit findEmployee() {
		ArrayList<String> name = new ArrayList<String>();
		EmployeeAudit audit = (salary) -> {
		    Set<String> keySet = employeeMap.keySet();
			for (String key : keySet) {
				if (employeeMap.get(key) <= salary) {
					name.add(key);
				}
			}
            // for(Entry<String, Double> entry: employeeMap.entrySet()){
            //     if(entry.getValue()<=salary){
            //         name.add(entry.getKey());
            //     }
            // }
			return name;
		};
		return audit;
	}

	public static void main(String[] args) {
		Map<String, Double> employeeMap = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		Main m = new Main();
		boolean flag = true;
		while (flag) {
			System.out.println("1.Add Employee Details");
			System.out.println("2.Find Employee Details");
			System.out.println("3.Exit");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			if (choice == 1) {
				System.out.println("Enter the Employee name");
				String empName = sc.next();
				System.out.println("Enter the Employee Salary");
				double empSalary = sc.nextDouble();
				m.addEmployeeDetails(empName, empSalary);
			}
			if (choice == 2) {
				System.out.println("Enter the salary to be searched");
				double searchSalary = sc.nextDouble();
				ArrayList<String> list = Main.findEmployee().fetchEmployeeDetails(searchSalary);
				if (list.isEmpty()) {
					System.out.println("No Employee Found");
				} else {
					for (String s : list) {
						System.out.println(s);
					}
				}

			}
			if (choice == 3) {
				System.out.println("Let's complete the session");
				flag = false;
				return;
			}
		}

	}

}
