public interface CommissionInfo {
 
 // Fill the code here 
  public double calculateCommissionAmount(Ticket ticketObj);
 
}