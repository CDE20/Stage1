package com.model;


public class RegistrationBean {


	private String userName;
	private long contactNumber;
	private String emailId;
	private String confirmEmailId;
	private boolean status;
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailId() {	 	  	    	    	     	      	 	
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getConfirmEmailId() {
		return confirmEmailId;
	}
	public void setConfirmEmailId(String confirmEmailId) {
		this.confirmEmailId = confirmEmailId;
	}

	@Override
	public String toString() {
		return "RegistrationBean [userName=" + userName + ", contactNumber=" + contactNumber + ", emailId=" + emailId
				+ ", confirmEmailId=" + confirmEmailId + ", status=" + status + "]";
	}
}
