var array = [];

function addFeedback(){
      var comment = document.getElementById('feedback').value;
      array.push(comment);
      document.getElementById('result').innerHTML= "<h2>Feedback Details</h2>"+"<h3>Successfully Added the Feedback Details</h3>";
}

function displayFeedback(){
    document.getElementById('result').innerHTML= "<h2>Feedback Details</h2>";
    for(var i = 0; i<array.length; i++){
        var para1 = document.createElement("P");
        var para2 = document.createElement("P"); 
        para1.innerText = "Feedback " + (i+1);
        para2.innerText = array[i];
        document.getElementById('result').appendChild(para1);
        document.getElementById('result').appendChild(para2);
    
    }
}