/**
 * 
 */
function cur_Date()
{
	var x=new Date();
	return x;
}