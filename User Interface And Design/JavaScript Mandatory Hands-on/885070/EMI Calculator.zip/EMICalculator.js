
function calculateEMI(){
    var P = document.getElementById('principalAmount').value;
    var ratePerAnnum = document.getElementById('interestRate').value;
    var R = (ratePerAnnum/100)/12;
    var N = document.getElementById('tenure').value;
    var base = 1+R;
    var power = Math.pow(base,N);
    var emi = (P * R * (power/ (power-1)));
    var result = emi.toFixed(2);
    document.getElementById('result').innerHTML = "EMI is Rs." +result;
    return false;
}