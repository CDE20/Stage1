import org.junit.Test;
import static org.junit.Assert.fail;
import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;

public class LoginTest {
    LoginDAO loginDao = new LoginDAO();
    Login login = new Login("mrinal_shubham","mrinal@123"); 
       	 
     @Test
     public void testAddingSuccess(){
        login.setUserName("mrinal_shubham");
        login.getUserName();
        login.setPassword("mrinal@123");
        login.getPassword();
        assertTrue(loginDao.addLogin(login));
     }
    
    @Test
    public void testAddingFailure(){
        assertFalse(loginDao.addLogin(null));
    }
    
    @Test
     public void testDelete(){
        loginDao.addLogin(login);
        assertTrue(loginDao.deleteLogin(login));
     }
    
    @Test
    public void testDeleteFailure(){
        assertFalse(loginDao.deleteLogin(null));
    }
    
}
