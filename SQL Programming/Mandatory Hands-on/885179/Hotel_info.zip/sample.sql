select concat(hotel_name,'is a',hotel_type,'hotel') as HOTEL_INFO from hotel_details
order by hotel_name desc;