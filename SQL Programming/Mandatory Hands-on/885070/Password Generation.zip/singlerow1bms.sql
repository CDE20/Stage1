SELECT name,concat(substring(name,1,3),substring(phno,1,3)) AS Password FROM users
ORDER BY name;