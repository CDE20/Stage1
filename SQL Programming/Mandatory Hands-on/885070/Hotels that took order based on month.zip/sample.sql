SELECT DISTINCT hotel_details.hotel_id, hotel_name,rating FROM hotel_details
WHERE hotel_details.hotel_id IN (SELECT orders.hotel_id FROM orders where extract(month from orders.order_date)='07')
ORDER BY hotel_id;