SELECT partner_id, partner_name, phone_no FROM delivery_partners 
WHERE rating BETWEEN 3 AND 5 
ORDER BY partner_id;