SELECT rental_id,car_id,customer_id,km_driven FROM rentals
WHERE extract(month FROM return_date) = '8' 
ORDER BY rental_id;