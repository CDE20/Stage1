SELECT student.student_name,department.department_name FROM student 
JOIN department ON student.department_id=department.department_id
WHERE student.city="Coimbatore" 
ORDER BY student_name ;