SELECT concat(address,",",city) AS Address FROM student 
ORDER BY Address DESC;