SELECT distinct users.name,users.address FROM users, bookingdetails 
where users.user_id = bookingdetails.user_id and bookingdetails.user_id NOT IN (SELECT user_id FROM bookingdetails WHERE name="HDFC")
ORDER BY name;