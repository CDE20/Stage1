SELECT concat(hotel_name, "is a", hotel_type, "hotel") AS HOTEL_INFO FROM Hotel_details
ORDER BY HOTEL_INFO DESC;